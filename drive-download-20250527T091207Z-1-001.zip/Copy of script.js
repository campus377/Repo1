document.getElementById('menu-btn').addEventListener('click', function() {
    alert('Menu clicked!');
});

document.getElementById('notification-btn').addEventListener('click', function() {
    alert('Notifications clicked!');
});

document.getElementById('search-btn').addEventListener('click', function() {
    alert('Search clicked!');
});
